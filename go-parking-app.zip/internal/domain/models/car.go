package models

type Car struct {
	RegistrationNumber string
}